package cn.itheima.gjp.app;

import cn.itheima.gjp.web.MainJFrame;

public class MainApp {

   public static void main(String[] args) {
	   MainJFrame mj = new MainJFrame();
	   mj.setVisible(true);
   }
}
